-   [Showbox](https://www.showbox.media/download) - Unlimited movies and TV shows for free
-   [CloudStream-3](https://github.com/LagradOst/CloudStream-3) - Android app for streaming and downloading Movies, TV-Series and Anime
-   [Stremio](https://www.stremio.com/) - A modern media center that's a one-stop solution for your video entertainment. You discover, watch and organize video content from easy to install addons
-   [TeaTV](https://teatv.net/) - Free 1080p Movies and TV Shows for Android, Windows & macOS Devices
-   [VivaTV](https://www.vivatv.io/) - An Android application allowing user to watch movies & tv shows for free on Android device, Amazon Fire TV, Nvidia Shield, etc
-   [NovaTV](https://novatv.app/) - An Android application allowing user to watch movies & tv shows for free on Android device, Amazon Fire TV, Nvidia Shield, etc
-   [FilmPlus](https://filmplus.app/) - A brand new Android application to watch free movies and tv shows on Android phones, Android TVs and Amazon Firesticks
-   [BeeTV](http://beetvapk.me/) - Watch movies & tv shows for free on Android device, Amazon Fire Stick, Fire TV, Nvidia Shield, etc
-   [HD STREAMZ](https://hdstreamz.app/) - A great application that has been able to integrate channels from different countries around the world. People will enjoy more than 1000 channels and live show from this app
-   [Popcorn Time](https://github.com/popcorn-official) - A multi-platform, free software BitTorrent client that includes an integrated media player.
-   [Cucotv](https://cucoapptv.github.io/) - Streaming Movies, Series on Android devices. You can stream videos to Smart TV, FireStick, Chromecast, Roku, MiBox, PlayStation, Xbox, Mac, PC, etc

# Android

-   [Thunder ⚡️](https://github.com/anujd64/Thunder) - An Android app to stream and download your media stored in Google Drive(require setup Google Drive index website) in an Awesome way !!

    > ⚡️ [Getting Started](https://github.com/anujd64/Thunder#-getting-started-)
    >
    > ⚡️ Features : [More](https://github.com/anujd64/Thunder#-features-)
    >
    > -   Stream and Download media directly
    > -   Add to watchlist
    > -   Import/Export for database
    > -   Support GdIndex, GoIndex, MapleIndex, SimpleProgram
    > -   New Release On Home
    >
    > 🔗 [Telegram Support Group](https://t.me/+p-ODqJeW-6FjNTI1)
    >
    > ⚡️Download: [Release](https://github.com/anujd64/Thunder/releases)
