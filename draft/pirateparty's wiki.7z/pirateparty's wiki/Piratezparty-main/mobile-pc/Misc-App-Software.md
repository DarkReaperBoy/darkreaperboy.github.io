# Android

-   [Termux Monet](https://github.com/HardcodedCat/termux-monet) - **Termux-Monet** is a unofficial, modified fork of Termux, an Android terminal application and Linux environment, with Monet Theming Implementations. ⭐
    > Monet means Material You theme!!
-   [Mathematics](https://play.google.com/store/apps/details?id%3Dde.daboapps.mathematics) (Android app name) - Calculator with many cool stuff related to math like graph and it calculates algreba, function, formula, etc. ⭐
-   [anemo](https://github.com/2bllw8/anemo) | [Fdroid](https://f-droid.org/packages/exe.bbllw8.anemo/) - A open-source Local private storage for Android
    > Anemo is a private local storage utility application for android. Instead of being a stand-alone file manager user interface, it hooks into various components of Android making it feel like a native part of the operative system. Moreover it provides ways for the user to export contents from other apps and save them as files.
-   [Gesture Suite](https://play.google.com/store/apps/details?id=com.gesture.suite) - one gesture app to rule them all
-   [CapShot: Beautiful Screenshots](https://play.google.com/store/apps/details?id=me.aravi.capshot) - an editor that lets you create polished and professional-looking shots in just seconds. (Pretty screenshots on phone)

# Window

-   [United Sets](https://apps.microsoft.com/store/detail/united-sets-preview-beta/9N7CWZ3L5RWL) - It allow you to group other softwares together in browser-like window and each software represent as tab, helpful for multi-tasking.
-   [Shell](https://nilesoft.org/) | [Report/track issues on issue repo](https://github.com/moudey/shell)(NO open source ig ) - Powerful manager for Windows File Explorer context menu(right click menu)(many features added in context menu).
-   [Flow Launcher](https://github.com/Flow-Launcher/Flow.Launcher) - 🔍 A Quick file search & app launcher for Windows with community-made plugins
-   [PowerToys](https://github.com/microsoft/PowerToys) - Increase your productivity with a range of tools for windows
-   [JaxCore](https://github.com/Jax-Core/JaxCore) - JaxCore is a collection of utility modules designed to improve your desktop experience and increase your productivity. Core is a configuration hub that allows for quick access to settings, updates, and new releases.
    -   JaxCore (configuration hub) acts as a settings menu for all JaxCore modules, while providing continuous support for patch / feature updates. It also allows you to access other modules more quickly!
-   [Microsoft ~~Software~~ OS Download List](https://ave9858.github.io/msdl/) - Actually Microsoft all OS Download list not Software
-   [Microsoft Office Electron](https://github.com/agam778/MS-Office-Electron) - This project is basically a Unofficial Desktop wrapper for the web version of Microsoft 365, which is free but with some basic limits.
    (In readme developer say he wanted to use Microsoft 365 on my Linux system with a native experience, so he made this)
    > cc: https://t.me/agamtechtricks/5770

# Apple 🍎 ( IOS & MacOS)

-   [ServerCat](https://servercat.app/) - Server Status, Docker Management and SSH client for iOS/macOS.
