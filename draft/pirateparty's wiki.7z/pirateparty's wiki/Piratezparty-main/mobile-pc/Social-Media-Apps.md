# Discord

-   [Aliucord](https://github.com/Aliucord/Aliucord) - Android
-   [Bluecord](https://github.com/bluemods/Bluecord) | [Website](https://bluesmods.com/) - Android
-   [Vendetta](https://github.com/vendetta-mod) | [Website](https://vendetta.vercel.app/) - Android
-   [BetterDiscord](https://github.com/BetterDiscord/BetterDiscord) | [Website](https://betterdiscord.app/) - Desktop
-   [PowerCord](https://github.com/powercord-org) | [Website](https://powercord.dev/) - Desktop

# Telegram

-   Telegram [Android](https://github.com/DrKLO/Telegram)/[IOS](https://github.com/TelegramMessenger/Telegram-iOS)/[Desktop](http://github.com/telegramdesktop/tdesktop) - Android/IOS/Desktop
-   [NekoX](https://github.com/NekoX-Dev/NekoX) - Android
-   [Telegram-FOSS](https://github.com/Telegram-FOSS-Team/Telegram-FOSS) - Android
-   Forkgram [Android](https://github.com/Forkgram/TelegramAndroid)/[Desktop](https://github.com/Forkgram/tdesktop) - Android/Desktop
-   [TelegramX](https://t.me/tgx_log) | [GitHub](https://github.com/TGX-Android/Telegram-X) - Android
-   [Nekogram](https://nekogram.app/) | [GitLab](https://gitlab.com/Nekogram/Nekogram) - Android
-   [Telegraher](https://github.com/nikitasius/Telegraher) - Android
-   [exteraGram](https://github.com/exteraSquad/exteraGram) - Android
-   [Nagram](https://github.com/nextalone/nagram) - Android
-   [Nnngram](https://github.com/PreviousAlone/Nnngram) - Android
-   [Nullgram](https://github.com/qwq233/Nullgram) - Android
-   [CherryGram](https://github.com/arsLan4k1390/Cherrygram) - Android
-   [OctoGram](https://github.com/OctoGramApp/OctoGram) - Android
-   AyuGram [Android](https://github.com/AyuGram/AyuGram4A )/[Desktop](https://github.com/AyuGram/AyuGramDesktop) - Android/Desktop
-   [NinjaGram](https://play.google.com/store/apps/details?id=me.ninjagram.messenger) - Android (Outdated/Discontinued) (Closed source)
-   [PlusMessenger](https://plusmessenger.org) - Android (Closed source)
-   [TurboTel Pro](https://play.google.com/store/apps/details?id=ellipi.messenger) - Android (Closed source)
-   [Graphmessenger](https://www.graphmessenger.com/) - Android (Closed source)
-   [Aka](https://play.google.com/store/apps/details?id=org.aka.messenger) - Android (Closed source)
-   [Catogram](https://github.com/Catogram/Catogram) - Android (Outdated/Discontinued)
-   [CatogramX](https://github.com/CatogramX/CatogramX) - Android (Outdated/Discontinued) 
-   iMe Messenger [Android](https://github.com/imemessenger/iMe-Android)/[IOS](https://github.com/imemessenger/iMe-iOS) - Android/IOS (Outdated/Discontinued)
-   [BGram](https://github.com/BGramApp/BGramFiles) - Android (Outdated/Discontinued)
-   [OwlGram](https://github.com/OwlGramDev/OwlGram) - Android (Outdated/Discontinued)
-   [nicegram](https://github.com/nicegram/Telegram-iOS) - IOS
-   [Postufgram](https://github.com/Postuf/Telegram-iOS-Double-Bottom-Postufgram) - IOS (Outdated/Discontinued)
-   [Unigram](https://github.com/UnigramDev/Unigram) - Desktop
-   [64Gram](https://github.com/TDesktop-x64) - Desktop
-   [Kotatogram](http://github.com/kotatogram/kotatogram-desktop) - Desktop (Outdated/Discontinued)

# Reddit

-   [Infinity](https://github.com/Docile-Alligator/Infinity-For-Reddit) - Android
-   [Dawn](https://github.com/Tunous/Dawn) - Android
-   [Slide](https://github.com/Haptic-Apps/Slide) - Android
-   [Boost](https://boostforreddit.com/) - Android
-   [Relay](https://play.google.com/store/apps/details?id=free.reddit.news) - Android
-   [Sync](https://play.google.com/store/apps/details?id=com.laurencedawson.reddit_sync) - Android
-   [Joey](https://play.google.com/store/apps/details?id=o.o.joey) - Android
-   [Baconreader](https://baconreader.com/) - Android
-   [RedReader](https://github.com/QuantumBadger/RedReader) - Android

# Instagram

-   [Instander](https://thedise.me/instander/) - Android
-   [AeroInsta](https://aeroinsta.com/) - Android

# Twitter

-   [AeroWitter](https://aerowitter.com/) - Android
-   [Harpy](https://github.com/robertodoering/harpy) - Android

# Whatsapp
> Using whatsapp will not allow google backup, you have to do local backup (one happen before google backup when try to do google one) and then delete whatsapp mod and install normal, normal will look for local backup but sometimes miss/fail so be careful.

> same way to transfer data to mod version

-   [WhatsApp AERO](https://whatsaero.com/) - Android
-   [YMWhatsApp+](https://ymwhatsapp.com/) - Android
-   [BETALABS](http://deltalabsproject.blogspot.com/) - Android
-   [Fouad WhatsApp](http://Down.fouadmods.com) - Android

# Signal

-   [Molly](https://github.com/mollyim/mollyim-android) - Android
