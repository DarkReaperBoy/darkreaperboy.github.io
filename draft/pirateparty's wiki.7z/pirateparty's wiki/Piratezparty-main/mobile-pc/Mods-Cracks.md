# Recommended Places to start your Mods/Cracks Journey

## Mobile

-   In Telegram : [Modzilla](https://t.me/Modzilla) , [Modded Central](https://t.me/moddedcentralbackup) , [Amrts](https://t.me/AMRTSOFFICIAL) , [PA4FreeReborn](https://t.me/PA4FreeReborn)

-   Website : [Mobilism](https://forum.mobilism.me/), [Modding United](http://www.moddingunited.xyz/) , [Rockmods](https://www.rockmods.net/) , [Androeed](https://www.androeed.ru/)

-   Apps (Playstore of mods XD) : [Mobilism](http://forum.mobilism.org/app)

-   Alternative of playstore : [Fdroid(for Opensource apps)](https://www.f-droid.org/) , [Aptoide](https://en.aptoide.com/) , [Apkpure](https://m.apkpure.com/) , [Apkmirror](https://www.apkmirror.com/)

## PC

-   Websites/Forums : [Nsaneforums](https://nsaneforums.com/) , [Filecr](http://filecr.com/) , [sanet.st](http://sanet.st/) , [appnee](https://appnee.com/) , [Rutracker](http://rutracker.net/) , [Ru-board](https://forum.ru-board.com/) , [Aiowares](https://aiowares.com/) , [Mydigitallife](https://forums.mydigitallife.net/) , [Getintopc ](http://getintopc.com/)(use as last resort)

-   Repacks : [Lrepacks](http://lrepacks.ru/) , [Rsload](http://rsload.net/) , [Repack.me](http://repack.me/)

-   Telegram : [Aiosetup](https://t.me/aiosetup) , [keygen_fortress](https://t.me/keygen_fortress)

## IMPORTANT NOTES :

1. This list is not for best modding sites. This list is made, keeping in mind new users who don't know which site to use and end's up downloading viruses.

2. Browse with uBlock Origin at all times to block popups and ads, thus avoiding any malicious downloads.

3. Is this release/file safe?
   If you have any doubt you can run it in VM Or Sandbox to test it. For android you can use [shelter](https://github.com/PeterCxy/Shelter) or [Island](https://github.com/oasisfeng/island/) and stuff like that as well.

4. Read this for better understanding of how to avoid viruses - [Thesis On Zero Day Cracked Software, Games & Online Scanner Virus Detection](https://onehack.us/t/thesis-on-zero-day-cracked-software-games-online-scanner-virus-detection/96856)

# Websites for Mod apks(DDL)

-   [Mobilism](https://forum.mobilism.org/index.php)
-   [piratedhub](https://piratedhub.com/)
-   [a2zapk](https://a2zapk.com/)
-   [dlandroid](https://dlandroid.com/)
-   [AK-Mods](https://www.akmods.in/)
-   [APKs.me](https://apks.me)
-   [apk4all](https://apk4all.com/)
-   [rexdl](http://rexdl.com/)
-   [apk4all](https://apk4all.com/)
-   [4PDA](https://4pda.to/forum/)
-   [apkmody](https://apkmody.io/)
-   [5play](https://5play.ru/en/)
-   [apkmodhub](https://apkmodhub.in/)
-   [sourceforge](https://sourceforge.net/)
-   [moddroid](https://moddroid.com/)
-   [apk4free](https://apk4free.net/)
-   [platinmods](https://platinmods.com/)
-   [apkmos](https://apkmos.com/)
-   [release-apk](https://forum.release-apk.com/)
-   [androidp1](https://www.androidp1.com/en/)
-   [androeed](https://en.androeed.ru/)
-   [apkdone](https://apkdone.com/)
-   [an1](https://an1.com/)
-   [apk4free](https://apk4free.org/)
-   [apkdlmod](https://www.apkdlmod.com/)
-   [mundoperfecto](https://www.mundoperfecto.net/)
-   [ihackedit](https://ihackedit.com/)
-   [apkmb](https://apkmb.com/)
-   [revdl](http://www.revdl.net/)
-   [ModdingUnited](http://www.moddingunited.xyz/)
-   [RockMods](https://www.rockmods.net/)

# Websites/Forums for cracked pc software

-   [izofile](https://izofile.com/)
-   [cracksoftwareguru](https://cracksoftwareguru.com/)
-   [4macsoft](https://4macsoft.com/)
-   [monkrus](http://monkrus.ws/)
-   [rutracker](http://rutracker.net/)
-   [Ru-board](https://forum.ru-board.com/)
-   [sanet](http://sanet.st/)
-   [getintopc](https://getintopc.com/)
-   [onhax](https://onhax.eu/)
-   [aiowares](https://www.aiowares.com/)
-   [nsaneforums](https://www.nsaneforums.com/)
-   [appnee](https://appnee.com/)
-   [solidshare](http://solidshare.net/)
-   [delta-repacks](http://delta-repacks.site/)
-   [repack](https://repack.me/)
-   [rsload](http://rsload.net/)
-   [mazterize](https://www.mazterize.com/)
-   [piratedhub](https://piratedhub.com/)
-   [lrepacks](https://lrepacks.ru/)
-   [crackingpatching](http://crackingpatching.com/)
-   [haxnode](https://haxnode.com/)
-   [filecr](http://filecr.com/)
-   [MyDigitalLife](https://forums.mydigitallife.net/)
