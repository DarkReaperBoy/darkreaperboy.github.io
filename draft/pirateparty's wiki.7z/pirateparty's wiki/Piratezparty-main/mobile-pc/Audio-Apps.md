# Spotify (Hehe)

-   [Spotx](https://github.com/amd64fox/SpotX) - Spotify mod remove ads and other features for Window
-   [xManager](https://github.com/Team-xManager/xManager) - Spotify Mod (Download and Manage mod) for Android

# Audio Editor/Recoder

-   [Audacity](http://www.audacityteam.org/) - Sound recording and post-processing.
-   [Ardour](https://ardour.org/) - Digital Audio Workstation (DAW).
-   [Libre.fm](https://libre.fm/) - Stream, download, remix, and share music for free.
-   [LMMS](https://lmms.io/) - Complete digital audio workstation.
-   [mStream](http://mstream.io/) - Suite of software for syncing and streaming music across multiple devices.

# Music Downloader

-   [SpotiFlyer](https://github.com/Shabinder/SpotiFlyer) - Android/Desktop
-   [Songtube](https://github.com/SongTube/SongTube-App) - Android
-   [Musify](https://github.com/Harsh-23/Musify) - Android
-   [AbleMusicPlayer](https://github.com/uditkarode/AbleMusicPlayer) - Android
-   [BlackHole](https://github.com/Sangwan5688/BlackHole) - Android/Desktop
-   [Serenity](https://github.com/YajanaRao/Serenity) - Android
-   [Freezer](https://t.me/freezerandroid) - Android
-   [Deezloader](https://www.deezloader.app/) - Android
-   [d-fi](https://github.com/d-fi/releases) - Desktop
-   [Youtube-Music](https://github.com/th-ch/youtube-music) - Desktop
-   [Deemix](https://deemix.app/) - Desktop
-   [Deezloader](https://www.deezloader.app/) - Desktop

# Music Player/Server

-   [Nuclear Music Player](https://nuclear.js.org/) - Desktop | Streaming music player that finds music from free sources automatically.
-   [TimberX](https://github.com/naman14/TimberX) - Android
-   [VinylMusicPlayer](https://github.com/AdrienPoupa/VinylMusicPlayer) - Android
-   [RetroMusicPlayer](https://github.com/RetroMusicPlayer/RetroMusicPlayer) - Android
-   [Ultrasonic](https://github.com/ultrasonic/ultrasonic) - Android
-   [Metro](https://github.com/MuntashirAkon/Metro) - Android
-   [Music-Player-GO](https://github.com/enricocid/Music-Player-GO) - Android
-   [Shuttle](https://github.com/timusus/Shuttle) - Android
-   [canaree](https://github.com/ologe/canaree-music-player) - Android
-   [Auxio](https://github.com/OxygenCobalt/Auxio) - Android
-   [Musicolet](https://play.google.com/store/apps/details?id=in.krosbits.musicolet) - Android | Multiple queues supported.
-   [S2 Music Player](https://play.google.com/store/apps/details?id=com.simplecityapps.shuttle) - Android
-   [Pulse Music](https://play.google.com/store/apps/details?id=com.hardcodecoder.pulse) - Android
-   [Stellio](https://stellio.ru/en) - Android
-   [BlackPlayer](https://play.google.com/store/apps/details?id=com.musicplayer.blackplayerfree) - Android
-   [MediaMonkey](https://www.mediamonkey.com/) - Android/Desktop
-   [Aimp](https://www.aimp.ru/) - Android/Desktop
-   [Veezee Android](https://github.com/veezee-music/veezee-android)/[Web](https://github.com/veezee-music/veezee-web) - Android/Web
-   [Nukeop](https://github.com/nukeop/nuclear) - Desktop
-   [Dopamine](https://github.com/digimezzo/dopamine-windows) - Desktop
-   [Apple Music for Windows](https://github.com/imxeno/apple-music-windows) - Desktop
-   [Rhyme](https://github.com/Rhyme-Player/Rhyme) - Desktop
-   [Foobar2000](https://www.foobar2000.org/) - Desktop
-   [MusicBee](https://www.getmusicbee.com/) - Desktop
-   [MediaMonkey](https://www.mediamonkey.com/) - Desktop
-   [Aimp](https://www.aimp.ru/) - Desktop
