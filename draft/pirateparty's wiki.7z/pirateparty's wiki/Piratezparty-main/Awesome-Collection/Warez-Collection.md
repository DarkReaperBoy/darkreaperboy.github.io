**1. Wotaku**
-   [Wotaku's Index](https://wotaku.its.moe/)

**2. Course Piracy Index**

-   [Course-Piracy-Index](https://github.com/ItIsMeCall911/Course-Piracy-Index)

**3. r/Pirated Games Megathread**

-   [Pgames-mega-thread](https://rentry.org/pgames-mega-thread)

**4. Indian Piracy Index**

-   [Indian-Piracy-Index](https://github.com/anymeofu/Indian-Piracy-Index)

**5. One website for all your needs**

-   [Weboas](https://weboasis.app/)

**6. AnimePiracy**

-   [TheIndex](https://theindex.moe/)
-   [TheWiki](https://thewiki.moe/)
-   [Awesome-anime-sources](https://github.com/anshumanv/awesome-anime-sources)


**7. Awesome Piracy**

-   [awesome-piracy](https://github.com/Igglybuff/awesome-piracy/)
-   [awesome-piracyv2](https://github.com/Shakil-Shahadat/awesome-piracy)

**8. Warezz.now.sh**

-   [Warezzsh](https://piracy.vercel.app/)

**9. FreeMediaHeckYeah**

-   [FMHY](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index) | [Website](https://fmhy.tk/) - [Website2](https://fmhy.pages.dev/)

**10. CHEF-KOCH/Warez**

-   [Chef-koch/Warez](https://libraries.io/github/CHEF-KOCH/Warez)

**11. eye.eu/piracy**

-   [eye.eu/public-piracy](https://the-eye.eu/public/Piracy/)

**12. MegaTKC/IPTV-Channels**

-   [IPTV-Channels](https://github.com/MegaTKC/IPTV-Channels)

**13. Awesome IPTV**

-   [IPTV](https://github.com/iptv-org/iptv)

**14. r/SoftwarePirates Megathread**

-   [SoftwarePirates-Megathread](https://rentry.org/SoftwarePirates-Megathread)

**15. r/APKsAPPs Megathread**

-   [Apks](https://apksapps.notion.site/096ef38f452342ba99b4e1509a449729?v=9970360b443643789c333bd2c7180009)

**16. r/Piracy Megathread**

-   [Piracy/Wiki/index](https://www.reddit.com/r/Piracy/wiki/index)

**17. Ripped Piracy**

-   [Ripped](https://github.com/rippedpiracy/docs) | [Website](https://ripped.guide/)

**18. The Pirate List**

-   [Thepiratelist](https://thepiratelist.com/)

**19. LightNovel Site Dump**

-   [LN-Site-Dump](https://docs.google.com/spreadsheets/d/1KGPLcSikfMgjtL7u8e2eiMQwDIgoAefOZsVrEzN9MQw/htmlview)

**20. Dirty Warez**

-   [Dirtywarez](https://dirtywarez.org/)


**21. Bestoflinks**

-   [Bestoflinks](http://bestoflinks.synology.me/)

**22. Unblockit**

-   [Unblockit](https://unblockit.boo/)
-   [Unblockninja](https://unblockninja.com/)
-   [Nocensor](https://nocensor.art/)
-   [Unblocked](https://unblocked.how/)

**23. Pirates Neverland**

-   [Pirates Neverland](http://www.neverland.ws/index.html)

**24. Piratesites.com**

-   [Piratesites](https://web.archive.org/web/20200317192929/https://piratesites.com/)

**25. Sajayprakash/megathread**

-   [Megathread](https://github.com/sajayprakash/megathread)

**26. 3DB7 Website List**

-   [3db7](https://3db7.xyz/stream/website)

**27. Linkr**

-   [linkr](https://www.linkr.top/)

**28. Morrismotel**

-   [morrismotel](https://morrismotel.com/)

**29. r/Mangapiracy Index**

-   [Mangapiracy](https://www.reddit.com/r/mangapiracy/about/)

**30. IDatabase**

-   [iDatabase](https://telegra.ph/Resources-11-28)

**31. Awesome German Piracy**

-   [awesome-german-piracy](https://github.com/SeppPenner/awesome-german-piracy)

**32. Useful Stuff**

-   [fulquit.github.io](https://github.com/fulquit/fulquit.github.io)

**33. Web-Indexer**

-   [Web-Indexer](https://oshekharo.github.io/Web-Indexer/) | [Piracyindex](https://piracy-index.ml) | [GitHub Link](https://github.com/OshekharO/Web-Indexer)

**34. Everything Adobe Piracy**

- [r/GenP/wiki](https://www.reddit.com/r/GenP/wiki/index/)
