# General

_Websites for easing the life of weebs_

-   [Animeawards](https://animeawards.moe/)
-   [Animekarmalist](https://animekarmalist.com/)
-   [A Certain Fansubber's Index](https://index.fansubcar.tel/)
-   [Seadex Index](http://releases.moe/) | [Sneedex](http://Sneedex.moe)
-   [r/anime watch order](https://reddit.com/r/anime/w/watch_order)
-   [Fansubdb](https://fansubdb.com/) - Fansub Related Data
-   [Bakaupdates](https://www.mangaupdates.com/index.html) - Website to find specific titles you're looking for.
-   [Anidb](https://anidb.net/)
-   [Novelupdates](https://www.novelupdates.com/)
-   [Scanupdates](https://www.scanupdates.com/)
-   [Manga Update](https://www.manga-raw.club/listy/manga/)
-   [Animefillerlist](https://animefillerlist.com) - Websites to list filler anime episodes.
-   [SauceNao](https://saucenao.com/) - Reverse image search
-   [Animeplus](https://anime.plus/) - An extension of your myanimelist.net profile, showing you various stats about your anime and manga.
-   [Anitrendz](https://anitrendz.com/) - Trending anime list.
-   [Fansubco](https://fansub.co/) - Fansub comparison site, dead now.
-   [Crymore](https://www.crymore.net/) - Reviews, comparison etc.

# Anime Tracking

_For Current Season Anime And tracking anime_

-   [Senpai](https://www.senpai.moe/)
-   [Animecorner](https://Animecorner.me/)
-   [Anichart](https://anichart.net/airing) | [AniList](https://anilist.co/)
-   [Livechart](http://livechart.me/)
-   [Myanimelist](https://myanimelist.net/)
-   [Animeschedule](https://animeschedule.net/)
-   [Animecalendar](http://animecalendar.eu/)

# Wikis

_Reddit wikis for Manga/Manhwa/Manhua etc which includes official publications and much more_

-   [Manhwa](https://www.reddit.com/r/manhwa/about/)
-   [Manhua](https://www.reddit.com/r/manhua/about/)
-   [Manga](https://reddit.com/r/manga/w/index)
-   [Webtoons](https://reddit.com/r/webtoons/w/index)
-   [Comicbooks](https://www.reddit.com/r/comicbooks/about/)
-   [Noveltranslation](https://reddit.com/r/noveltranslations/w/index)
-   [Anime](https://www.reddit.com/r/anime/about/)
