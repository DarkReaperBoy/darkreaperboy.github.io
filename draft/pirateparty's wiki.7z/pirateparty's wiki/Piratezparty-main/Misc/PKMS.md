# PKMS


## Note Taking

-   [Obsidian](https://obsidian.md/)
-   [Logseq](https://logseq.com/)
    > Obsidian vs Logseq biggest battle, logseq has daily journal feature and both good

> Just search obsidian vs logseq you will find many video/articles but none explain what you should use because it depends on your preference

## Journal

-   [Diarium](https://play.google.com/store/apps/details?id%253Dpartl.Diarium) - Android app for journal
-   [Journalist](https://play.google.com/store/apps/details?id%253Dcom.journalisticapp.twa) - Same as Diarium
