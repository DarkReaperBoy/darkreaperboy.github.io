# Websites to watch Korean and Chinese Drama

-   [kissasian](https://kissasian.li/)
-   [asianload](https://asianload.cc/)
-   [dramanice](https://dramanice.bz/)
-   [dramacool](https://dramacool.cy/)
-   [viewasian](https://viewasian.co/)
-   [dramago](https://dramago.icu/)
-   [viki](https://www.viki.com/)
-   [gooddrama](https://gooddrama.one/) - _Online+DDL_
-   [myasiantv](https://myasiantv.cc/) - _Online+DDL_
-   [newasiantv](https://www2.newasiantv.pro/)
-   [dramafans](http://www.dramafans.org/)
-   [kisskh](https://kisskh.co/)
-   [onetouchtv](https://onetouchtv.me/)
-   [asiaflix](https://asiaflix.app/)
-   [asiancrush](https://www.asiancrush.com/)
-   [goplay](https://goplay.ml/) note: if need access token go to their discord and generate access token(https://discord.gg/yY2P3DQR8S).
-   [newhkdrama](https://www.newhkdrama.com/)
-   [ivdrama](https://ivdrama.me/)
-   [kdramahood](https://kdramahood.com/)
-   [asianmovies](https://asiansmovies.com/)
-   [kisstvshow](https://kisstvshow.to/)

# Websites to Download Korean and Chinese Drama

-   [mkvdrama](https://mkvdrama.com/)
-   [dramaday](https://dramaday.net/)
-   [kingdrakor](https://kingdrakor.shop/)
-   [doramax264](https://doramax264.com/)
-   [bagikuy](https://bagikuy.com/)
-   [dramahd](https://dramahd.me/)
-   [dramasdrive](https://dramas-drive.sujalgoel.me/0:/)
-   [minidrama](https://minidrama.net/)
-   [sinflixrentry](https://rentry.co/sinflix)
-   [kmdl](https://kmdlbd.tk/)
-   [torrentsir](http://torrentsir106.com/)(Torrent)
-   [torrentqq](http://torrentqq.net/)(Torrent)
