# Where To Find Games

## Search Multiple Sites At Once For a Specific Game

_Always Use An AdBlocker! We Recommend uBlock Origin Browser extension_

-  [Game Search Engine](https://cse.google.com/cse?cx=006516753008110874046:cbjowp5sdqg)
-  [Crack Status For Games](https://crackwatch.com/)
-  [CS.RIN.RU](https://cs.rin.ru/forum/)
-  [Game Search](https://idleendeavor.github.io/gamesearch/)
-  [Rave Game Search](https://ravegamesearch.pages.dev/) | [GitHub](https://github.com/IdleEndeavor/gamesearch)
-  [Rezi](https://rezi.one/)

## PC

-  [FitGirl Repacks](https://fitgirl-repacks.site/)
-  [Masquerade Repacked](https://masquerade.site/)
-  [1337x](https://1337x.to/)
-  [DODI RePacks](http://dodi-repacks.site/)
-  [CrackHub - Scene](https://scene.crackhub.site/)
-  [ElAmigos Repacks](https://elamigos.site/)
-  [ScOOter Repacks](https://scooter-repacks.site/)
-  [GAMESDRIVE](https://gamesdrive.net/)
-  [SteamRIP](https://steamrip.com/)
-  [Kaoskrew](https://kaoskrew.org)
-  [Otxataba](https://otxataba.net)(Russian)
-  [Ova Games](https://ovagames.com)
-  [Rihnogames](https://rihnogames.com)
-  [Elamigos](https://elamigos.site)
-  [GoG Games](https://gog-games.com)
-  [Tiny Repacks](https://tiny-repacks.win)
-  [SkidrowReloaded](https://www.skidrowreloaded.com/)


_NOTE: Take Note Of The Game Uploaders Name & Download From Trusted Releasers Or Releasers You Are Familiar With. If You Have No Idea, Then Go For FitGirl Repacks. ThePirateBay & KickAss Are Unreliable Sources!_

## Android Games

_NOTE: Scan with [VirusTotal](https://VirusTotal.com) & Use Your Discretion._

-  [AN1](https://an1.com/)
-  [Androreed](https://www.androeed.ru/)
-  [Platin Mods](https://platinmods.com/)
-  [Mobilism](https://forum.mobilism.org/)

## ROM Sites:
-  [Ducumon](https://ducumon.me/)
-  [Myrient](https://myrient.erista.me/)
-  [Vimm](https://vimm.net/)

## Emulators:
-  [Launch Box](https://www.launchbox-app.com/) FrontEnd for Emulation
-  [PS2 Emulator](https://play.google.com/store/apps/details?id=xyz.aethersx2.android) - BIOS For [PS2](https://www.retrostic.com/bios)

## Browser Based Games

-  [poki](http://poki.com)
-  [Miniclip](http://miniclip.com/)

## Free Games Notification [get notified when games are free on steam,epic games etc platforms]

-  [EGS_Free_Games](https://t.me/EGS_Free_Games)
-  [Temporarilyfreegames](https://t.me/temporarilyfreegames)
-  [r/freegames](https://www.reddit.com/r/freegames)
-  [FreePcGames](https://play.google.com/store/apps/details?id=de.thegolem.freepcgames) - Application
-  [RSS OF Skidrow](https://t.me/LLPFDF) - Channel
-  [Free On Epic Games](https://t.me/FreeOnEpicGamesBot/) - Bot
-  [Free On Epic Games bot](https://t.me/egsnotifier_bot/) - Bot
-  [Free On Steam](https://t.me/FreeSteamOffers_Bot) - Bot
-  [Free Games Notifier](https://play.google.com/store/apps/details?id=com.arioch.efgr) - Applicationx

## Games On Sale

- [CheapShark](https://www.cheapshark.com/)

## Some Reddits For Game & Related updates/help And News

-  [CrackWatch](https://reddit.com/r/CrackWatch)
-  [PiratedGames](https://reddit.com/r/PiratedGames)
-  [CrackSupport](https://reddit.com/r/CrackSupport)
-  [FMHY Guide](https://reddit.com/r/FREEMEDIAHECKYEAH/w/games)

## Everything Minecraft

### Minecraft Bedrock/Pocket Edition
-  [MCPE Planet](https://mcpe-planet.com/) - Minecraft Bedrock Edition
-  [MCPEDL](https://mcpedl.org/downloading/) - Minecraft Bedrock Edition


### Minecraft Launchers

-  [GDLauncher](https://gdlauncher.com/)
-  [SkLauncher](https://skmedix.pl/)
-  [TitanLauncher](https://titan.mythicmc.org/)


### Minecraft Resources(Skins,Maps,Textures,ToolsEtc)

-  [Curseforge](curseforge.com/minecraft)
-  [MCPE-Planet.com](mcpe-planet.com)
-  [MCPEDL.ORG](mcpedl.org)
-  [MCPEDL.COM](mcpedl.com)
-  [Planet Minecraft](planetminecraft.com)
-  [Foxy NoTail](https://foxynotail.com/)
-  [Minecraft Tools](https://minecraft.tools/en/)

## Misc

-  [HowLongToBeat](https://howlongtobeat.com/) - Game Lengths, Backlogs and more!
-  [Google Play Games](https://play.google.com/googleplaygames) - Currently in Beta
-  [Compress Games folder](https://github.com/IridiumIO/CompactGUI) - Compress Games/Folders in pc without affecting their functions.

## Specific Mod/Private server of Games

-  [PGSharp](https://pgsharp.com/) - Pokemon Go with Spoof for Android(Free tier Available)
-  [IPogo](https://ipogo.app/) - Pokemon Go for both Android And IOS(Free & Paid)
- []
