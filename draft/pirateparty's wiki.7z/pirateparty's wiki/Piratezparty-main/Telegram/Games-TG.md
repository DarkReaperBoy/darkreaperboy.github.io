# Game Bots
- [inlinegamesbot](https://t.me/inlinegamesbot)
- [gamee](https://t.me/gamee)
- [HeXamon](https://t.me/HeXamonbot/) - Pokemon On TG
- [GameFactoryBot](https://GameFactoryBot) - Play chess on telegram
- [STRAWBERRYLOGICBOT](https://t.me/STRAWBERRYLOGICBOT/)
- [Werewolfbot](https://t.me/werewolfbot) - WereWolf Game
- [Minesweeper](https://t.me/minroobot) - Minesweeper
- [PokerGame](https://t.me/PokerBot) - Poker
- [Chessy Bot](https://t.me/CHESSY_BOT)
- [Chessy Bot](https://t.me/CHESSBOT)
- [](https://t.me/HOKMBAZIBOT)
- [](https://t.me/MENCHOOLBOT)
- [](https://t.me/SLGBOT)
- [](https://t.me/BM_XOBOT)
- [](https://t.me/OXBOT)
- [](https://t.me/XOBOT)
- [](https://t.me/NIMBOT)
- [](https://t.me/DREAMERSBOT)
- [](https://t.me/HEXAMONBOT)
- [](https://t.me/UCAHBOT)
- [](https://t.me/GAME100BOT)
- [](https://t.me/ASMFAMIL1BOT)
- [](https://t.me/CARDGAMESBOT)
- [](https://t.me/HOOSHROBOT)
- [](https://t.me/ROONXGAME_BOT)
- [](https://t.me/KALAMATORBOT)
- [](https://t.me/KALAMEBOT)
- [Wordi](https://t.me/WORDIBOT)
- [Awesome Games](https://t.me/AWESOMEBOT)
- [Gamebot](https://t.me/GAMEBOT)
- [Trivia Bot](https://t.me/TRIVIABOT) - Trivia

## Game files

_NOTE: Scan with [VirusTotal](https://VirusTotal.com) & Use Your Discretion._

- [IWannaPlay](@IWannaPlayBot) - Bot
- [Games Repack](https://t.me/irgi_dlya_pc) - Channel For Games Repack
- [Small  Games](https://t.me/SmallGamez)  - Official Channel of [Small Games](https://github.com/SpamVerse/Piratezparty/blob/main/Entertainment/Games.md#L26)