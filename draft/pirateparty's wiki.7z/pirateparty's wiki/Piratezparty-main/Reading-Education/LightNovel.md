# Websites To Read Light Novels

-   [octopii](https://octopii.co/)
-   [kisslightnovels](https://kisslightnovels.info/)
-   [lightnovelpub](https://www.lightnovelpub.com/)
-   [novelfull](https://novelfull.com)
-   [wuxiaworld](https://wuxiaworld.site/)
-   [novelonlinefull](https://novelonlinefull.com/)
-   [readlightnovel](https://www.readlightnovel.org/)
-   [novelcake](https://novelcake.com/)
-   [ https://daonovel](https://daonovel.com/)
-   [freewebnovel](https://freewebnovel.com/)
-   [asianhobbyist](https://www.asianhobbyist.com/)
-   [baka-tsuki](https://www.baka-tsuki.org/project/) - _Fan translation community_
-   [novelupdates](https://www.novelupdates.com/)
-   [jpmtl](https://jpmtl.com/) - _MTL_

# Websites to download light novels(DDL)

-   [thatnovelcorner](https://thatnovelcorner.com/)
-   [justlightnovels](https://justlightnovels.com/)
-   [lnwncentral.wordpress](https://lnwncentral.wordpress.com/)
-   [doadore](https://www.doadore.com/)
-   [mtlnovel](https://www.mtlnovel.com/) - _MTL_
-   [mtl.asianovel](https://mtl.asianovel.com/) - _MTL_
-   [lightnovelpdf](https://lightnovelpdf.com/)
-   [asianovel](https://www.asianovel.com)
-   [jnovels](http://jnovels.com/)
-   [armaell-library](https://armaell-library.net/)
-   [mp4directs](http://mp4directs.com/)
