# ► Gmail Alternatives

-   ⭐ [ProtonMail](https://proton.me/mail)
-   ⭐ [Tutanota](https://tutanota.com/)
-   [Disroot](https://disroot.org/en)
-   [Cock.li](https://cock.li/) - invite only.
-   [Outlook](https://outlook.live.com/owa/)

# ► TempMail

-   ⭐ [Temp-mail](https://www.temp-mail.org/)
-   ⭐ [Smailpro](https://www.smailpro.com/) - gamil / offers various other services as well.
-   ⭐ [EmailNator](https://www.emailnator.com/) - gmail
-   ⭐ [Trashmail](https://trashmail.com/)
-   [Email-fake](https://email-fake.com/)
-   [Emailondeck](https://www.emailondeck.com/)
-   [Maildrop](https://www.maildrop.cc/)
-   [Throwmail](https://www.throwmail.cc/)
-   [Mohmal](https://www.mohmal.com/en)
-   [10minutemail](https://www.10minutemail.com/)
-   [Yopmail](https://www.yopmail.com/)
-   [Emailfake](https://www.emailfake.com/)
-   [Gmailnator](https://gmailnator.com/) - Temp Gmail
-   [Getnada](https://getnada.com/)
-   [Throwawaymail](https://www.throwawaymail.com/en)
-   [Temp-mail](https://temp-mail.io/en)
-   [Mail.tm](https://mail.tm/en/)
-   [Tempail](https://tempail.com/en/)
-   [Yepmail](https://yepmail.co/)
-   [Mintemail](https://www.mintemail.com/)
-   [cs.email](https://www.cs.email/)

# ► Email Aliases

-   ⭐ [Firefox Relay](https://relay.firefox.com/)
-   ⭐ [Duckduckgo Email](https://duckduckgo.com/email/)
-   [Erine Email](https://erine.email/)
-   [Simplelogin](https://simplelogin.io/)
-   [Anonaddy](https://anonaddy.com/)
-   [0wx](https://www.0wx.org/0wx/?show=email)
-   [Forwardemail](https://forwardemail.net/en)
-   [33mail](https://www.33mail.com/)
-   [Spamgourmet](https://www.spamgourmet.com/index.pl)
-   [Burnermail](https://burnermail.io/)
-   [Shitmail](https://www.shitmail.org/)
-   [Trashmail](https://trashmail.com/)
-   [Improvmx](https://improvmx.com/)
-   [Altmails](https://altmails.com/)
-   [Abine](https://abine.com/)
