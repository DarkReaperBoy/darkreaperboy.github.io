-   [Redact](https://redact.dev/) - The only platform that allows you to automatically clean up your old posts from services like Twitter, Reddit, Facebook, Discord and more all in one place

-   [Saymine](https://www.saymine.com/) - Mine allows you to discover where your personal data is, and reduce your online exposure to minimize digital risks. Delete your data from services you no longer use that put you at risk.

-   [Telegram Delete All Messages](https://github.com/gurland/telegram-delete-all-messages) - Delete all your messages in groups / supergroups using this python script (can specify specific group)
