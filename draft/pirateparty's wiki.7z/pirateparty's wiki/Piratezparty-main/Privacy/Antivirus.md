-   [Malwarebytes](https://www.malwarebytes.com/) - Malwarebytes protects your home devices and your business endpoints against malware, ransomware, malicious websites, and other advanced online viruses.

-   [Virustotal](https://www.virustotal.com/) - Web service for scanning files and URLs for viruses.

-   [Bitdefender](https://www.bitdefender.com/) - Powerful, light weight antivirus protection software.

-   [Hitman pro](https://www.hitmanpro.com/en-us) - Cleans malware, viruses, trojans, worms, keyloggers, rootkits, trackers, spyware, and more.

-   [Eset](https://www.eset.com/) - Malware Protection and Internet Security.

-   [Kaspersky](https://www.kaspersky.co.in/) - AI-driven protection against hackers and the latest viruses, ransomware and spyware.

-   [ClamAV](https://github.com/Cisco-Talos/clamav) | [Website](https://www.clamav.net/) - Open source antivirus engine for detecting trojans, viruses, malware & other malicious threats.

**For more you can visit [r/antivirus Wiki](https://reddit.com/r/antivirus/w/index)**

**View Antivirus Benchmarks at [AV Test](https://www.av-test.org/en/)**
