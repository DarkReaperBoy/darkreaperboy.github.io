# Microsoft Guides

- Use the [Microsoft Office Deployment Tool](https://pastebin.com/jxqpcfAF) to get always latest installers from Microsoft  (Now supports Visio and Project as well!)

- [Office Guides For Noobs](https://rentry.org/officeguidefornoobs)

- [Clean install Microsoft Office](https://rentry.org/CLEAN-INSTALL-MICROSOFT-OFFICE)

- [Guide to Auto renew Msft E5 Developer subcription](https://graph.org/Guide-for-renewing-MSFT-E5-Dev-subscription-using-GitHub-Actions-03-25-2) | Note : this method can make your github account suspended.

