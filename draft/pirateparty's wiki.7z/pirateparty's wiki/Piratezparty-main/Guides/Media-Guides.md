# Guides Explaning How The Tech Works

-   [Small Guide on Cinema Tech](https://telegra.ph/Small-Guide-on-Cinema-Tech-06-07)
-   [Guide to play HDR](https://telegra.ph/Guide-to-play-HDR-06-20)
-   [Music Knowledge](https://telegra.ph/Music-Knowledge-05-19)
-   [Movie Piracy Termonology](https://whereyouwatch.com/articles/ultimate-guide-to-movie-piracy-termonology/) [[1]](https://telegra.ph/blueray-and-web-dl-12-16) [[2]](https://telegra.ph/Related-terms-to-Pirated-movie-release-types-12-17)
-   [FFmpeg Guides](https://telegra.ph/FFmpeg-Guides-06-19)
