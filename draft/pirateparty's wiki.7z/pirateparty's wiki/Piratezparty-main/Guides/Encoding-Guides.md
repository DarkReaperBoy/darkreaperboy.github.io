-   [Encoding Guide Neocities](http://encoding-guide.neocities.org)

-   [Yukisub Guides](https://yukisubs.wordpress.com/guides/)

-   [animemusicvideos Guides](https://www.animemusicvideos.org/guides/avtech31/)

-   [x265-readthedocs](https://x265.readthedocs.io/en/master/)

-   [LightArrowsEXE Encoding Projects](https://github.com/LightArrowsEXE/Encoding-Projects)

-   [Unanimated Guides](https://unanimated.github.io/)

-   [Fabsubbing Tutorial](https://subarashii-no-fansub.github.io/Subbing-Tutorial/)

-   [Aegisub Guides](https://aegisub.shinon71.moe/)

-   [Fabsubbing Guides](https://guide.encode.moe/)

-   [Silentaperture Encoding Guides](https://silentaperture.gitlab.io/mdbook-guide/)

-   [slhck ffmpeg encoding course](http://slhck.info/ffmpeg-encoding-course/#/)

-   [Iamscum Guides](https://iamscum.wordpress.com/)

-   [Goodjobmedia Fabsubbing Guide](http://goodjobmedia.com/fansubbing)

-   [Zencoder Encoding Guides](https://zencoder.support.brightcove.com/encoding-guides/index.html)

-   [Quanticdev Encoding Guides](https://quanticdev.com/articles/h265-encoding-on-arm-cpus/)

-   [Dpinetix Encoding Guides](https://support.spinetix.com/wiki/Encoding_guides)

-   [Fabsubbing Guide](https://guideencodemoe-mkdocs.readthedocs.io/)

-   [qshqencodingguide-EncodingGuide](https://github.com/Dobatymo/qshqencodingguide/blob/master/EncodingGuide.md)

-   [Guide To Mastering Handbrake](https://www.rapidseedbox.com/blog/guide-to-mastering-handbrake)

-   [HandBrake – H.265 NVEnc 1080p Ripping Chart and Guidelines](https://www.google.com/amp/s/www.ryananddebi.com/2020/10/04/handbrake-h-265-nvenc-1080p-ripping-chart-and-guidelines/amp/)

-   [HEVC Encoding with StaxRip settings for best compression](https://telegra.ph/HEVC-Encoding-with-StaxRip-Settings-for-best-compression-included-05-12)

-   [Blog kageru](https://blog.kageru.moe/)

-   [kokomin Guides](https://kokomins.wordpress.com/)

-   [YukinoAi - Fabsubbing and Encoding Guide](https://gist.github.com/YukinoAi/acea024631a2585aa592b16b4bde959f)

-   [Bodoicuho Guides](https://bodoicuho.ucoz.ru/)

-   [Encoding Guide By Neko Encodes](https://docs.google.com/document/d/1Ev_hqUnHAztvUxg4X3VFlb8W728wphg-el7K_4pPlr8/edit?usp=drivesdk)

-   [Archived Things](https://sometimes-archives-things.github.io/archived-things/)

-   [Ayumi Megui x264 Encoding Setting Guide HD Quality](https://ayumilove.net/ayumilove-megui-x264-encoding-settings-guide-hd-quality/)

-   [StaxRip Encoding Tutorial](https://staxrip.github.io/x265-encoding-tutorial/#configuring-the-video-encoder)

-   [Megui Wiki](https://en.wikibooks.org/wiki/MeGUI)

# Ffmpeg Guides

-   [ffmpeg.org/ffmpeg-all](https://ffmpeg.org/ffmpeg-all.html#) - _ffmpeg documentation_

-   [trac.ffmpeg](https://trac.ffmpeg.org/) - _ffmpeg wiki_

-   [ffmpeg-libav-tutorial](https://github.com/leandromoreira/ffmpeg-libav-tutorial)

-   [ffmpeg-for-beginners-processing-converting-and-streaming-video](https://api.video/blog/video-trends/ffmpeg-for-beginners-processing-converting-and-streaming-video)

-   [itsfoss/ffmpeg](https://itsfoss.com/ffmpeg/)

-   [gist.github-ffmpeg](https://gist.github.com/protrolium/e0dbd4bb0f1a396fcb55)

-   [ffmpeg-web-video-guide](https://gist.github.com/jaydenseric/220c785d6289bcfd7366)

-   [ffmpeg-commands](https://github.com/a-nagrani/ffmpeg-commands)

-   [ffmpeg encoding](https://gist.github.com/Vestride/278e13915894821e1d6f)

-   [FFmpeg cheat sheet](https://gist.github.com/steven2358/ba153c642fe2bb1e47485962df07c730)
