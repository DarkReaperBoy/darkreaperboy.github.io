-   [Installgentoo-PrivateTracker-wiki](https://wiki.installgentoo.com/index.php/Private_trackers) - In this article, you will be guided in how to get into (and survive) the world of private trackers.

-   [Private Trackers Spreadsheet](https://hdvinnie.github.io/Private-Trackers-Spreadsheet/) - Private Tracker Spreadsheet.

-   [PirateList](https://www.notion.so/Pirates-c6362fa7a32a47c5904b0509e9ca1cd3) - List of P2P release groups and Scene groups.

-   [Installgentoo-Seedbox-wiki](https://wiki.installgentoo.com/wiki/Seedboxes) - small info around seedbox.

-   [Seedboxgui](https://seedboxgui.de/) - An informative guide about seedboxes.

-   [Private Trackers](https://rentry.co/private-trackers) - A Guide About how private tracker works and information related all the Major Private Trackers.

-   [Trackers index](https://reddit.com/r/trackers/w/index) - Contains various information and data about public and private trackers.

-   [Private Tracker Guide](https://docs.google.com/spreadsheets/d/1SUza1pwLS1g8Hj1ah-H-C34ClzFl5xl74qeCSID1IoI/edit?usp=sharing) - List and Information about private trackers.

-   [Requirement Thread](https://files.catbox.moe/z8iw78.png) - Official recruitment threads to join respective Private Tracker.

-   [ScenevsP2P](https://www.reddit.com/r/Piracy/comments/b0c0ns/difference_between_the_scene_and_p2p/) - Difference between scene and p2p.
