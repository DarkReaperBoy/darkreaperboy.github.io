# Remove Files/Folders from Shared with Me section

> Open Google Drive on PC or in App.
> Go to Shared with Me section and select the Files/Folders you wanna remove.
> Now the most important part,
> After selecting the stuffs you wanna remove, use your mouse/touchpad to drag the Files/Folders into Trash folder section and after that just clear your Trash.

-   [Rclone Guides For Beginners](https://telegra.ph/Rclone-Guide-for-Beginners-04-15)

-   [How to create service accounts (sa)](https://telegra.ph/How-to-create-and-use-service-accounts-sa-03-31)

-   [Create credentials.json](https://telegra.ph/Create-credentialsjson-06-09)

-   [Telegram Channels](https://t.me/gdriveguides)
