# The Ultimate Twitter Client

> Revanced Twitter + TwiFucker = VanFucker

![](https://pbs.twimg.com/media/E-E-P_jVkAo7oYI?format=jpg&name=small)

1. Build Revanced Twitter through a builder of your choice. (Recommended : [reisxd](https://github.com/reisxd/revanced-builder))

    - Apply 'Dynamic Colors' 'Monochrome Icon' patches and leave out the 'Hide Timeline Ads' one to avoid any potential conflicts.

-   Rename the apk to twitter.apk

2. Download the latest TwiFucker apk from [GitHub](https://github.com/Dr-TSNG/TwiFucker/releases/)

3. Download LSPatch .JAR from [GitHub](https://github.com/LSPosed/LSPatch/releases)

4. Keep all the files in the same directory.

5. Building the VanFucker

    - Make sure Java is installed on your PC/Mac/Linux/Termux
    - cd into the directory with files.
    - Run `java -jar lspatch.jar twitter.apk -m twifucker-V.x.apk`
    - That's it.

6. Install the APK generated to enjoy VanFucker

USAGE : After logging in, go to "Settings and Privacy" > "Additional Resources" > Tap on the version number (top of the list).
You'll be presented with the TwiFucker Menu where you can customise [these features](https://github.com/Dr-TSNG/TwiFucker/blob/master/FEATURES.md) to your wish.
