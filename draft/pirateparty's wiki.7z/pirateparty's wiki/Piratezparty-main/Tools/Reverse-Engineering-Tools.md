# Reverse Engineering Tools

-   [ImHex](https://github.com/WerWolv/ImHex) - 🔍 A Hex Editor for Reverse Engineers, Programmers and people who value their retinas 👁 when working at 3 AM.
