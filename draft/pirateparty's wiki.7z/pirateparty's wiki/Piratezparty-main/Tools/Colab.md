-   [Torrent To Google Drive Downloader](https://github.com/AvinashReddy3108/Torrent-To-Google-Drive-Downloader) - Helps to easily upload torrent/magnet links to Google Drive!

-   [Torrent Drive Telegram Bot Using Colab](https://github.com/ogkunald/Torrent-Drive-Telegram-Bot-Using-Colab) - Simple Torrent to GDrive Telegram bot using colab.

-   [Clone Chat Telegram Colab](https://github.com/Drrivao/Clonechat-Telegram-Colab) - 💬 Clone telegram channels with Google Collaboratory

-   [RcloneLab](https://github.com/acamposxp/RcloneLab/network/members) - rclone GUI, qBittorrent and rTorrent on Google Colaboratory.

-   [MiXLab](https://github.com/shirooo39/MiXLab) - MiXLab is a mix of multiple amazing Colab Notebooks found on the internet.

-   [OneClickRun](https://github.com/biplobsd/OneClickRun) - All in one Colab Notebook.

-   [VT Scan Colab](https://colab.research.google.com/drive/10AZ7NkATPeUNO_ONcE8BUx8LeeipCvwX) - Scanning Files on drive using VirusTotal via Colab.

-   [Rclone file transfer](https://colab.research.google.com/drive/1GUb7TE712Xv_5yJf9cBPGK9qPT5A8CjU?usp=sharing) - Rclone file transfer in colab with resume.

-   [T0rr3nts-t0-G00gl3-Dr1v3](https://github.com/jericjan/Torrents-to-Google-Drive) - This is a Google Colab notebook with QBittorrent and Rclone, which can download torrents to Google Drive.

-   [Any-file-to-GoogleDrive](https://github.com/menukaonline/Any-file-to-Google-Drive) - This is a Google Colab notebook with Jdownloader and Rclone, which can download any file to Google Drive.

-   [Ytplaylist YoutubeDL](https://colab.research.google.com/github/aftabkh505/Ytplaylist/blob/master/styleYoutubedl.ipynb) - Download YouTube Videos and Playlist.

-   [Youtube-dl Toolbox](https://colab.research.google.com/github/online6731/youtube-dl-toolbox/blob/main/youtube_dl_toolbox.ipynb) - Video + Playlist Downloder Simple Mode.

-   [FFMPEG For Colab](https://github.com/cheems/FFmpeg-for-GDrive) - Run FFMPEG on Colab with Files Mounted from Gdrive.

-   [HandBrakeCLI-ColabNotebook](https://github.com/SKGHD/Handy) - HandbrakeCLI with Files Mounted from Gdrive.

-   [FastColabCopy](https://github.com/L0garithmic/FastColabCopy) - Python3 script to transfer files in Google Colab 10-50x faster.

-   [ZspotifyColab](https://github.com/Ori5000/zspotifycolab) - Zspotify on Google Colab with GUI Controls.
