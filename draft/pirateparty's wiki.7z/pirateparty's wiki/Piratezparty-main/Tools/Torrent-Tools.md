-   [swizzin.ltd](https://swizzin.ltd/) - _An all in one seedbox solution, including the most common seedbox apps. Actively developed, friendly developer_

-   [Exatorrent](https://github.com/varbhat/exatorrent) - _Self-hosted feature rich torrent client_

-   [Flood](https://github.com/jesec/flood) - _Alternative modern Web UI for various torrent clients_

-   [Torrentinim](https://github.com/sergiotapia/torrentinim) - _low memory-footprint, self hosted API-only torrent search engine_

-   [torrent-webseed-creator](https://github.com/AnimMouse/torrent-webseed-creator) - _Webseeded torrent creator using GitHub Actions_

-   [TorrentParts](https://github.com/leoherzog/TorrentParts) - _A website to inspect and edit what's in your Torrent file or Magnet link_

-   [tele-aria2](https://github.com/HouCoder/tele-aria2) - _A Telegram bot for controlling your aria2 server_

-   [nefarious](https://github.com/lardbit/nefarious) - _Web application for automatically downloading TV & Movies_
