# Telegram

-   [Killergram](https://github.com/Xposed-Modules-Repo/com.shatyuka.killergram) - An Android Xposed module to remove sponsored messages of Telegram
-   [TeleSpeed](https://github.com/Xposed-Modules-Repo/io.github.tehcneko.telespeed/) - Lsposed module to enhance your telegram client download speed.

# Instagram 

-   [Instaloader](https://github.com/instaloader/instaloader) - CLI based tool for instagram, Download everything from Instagram - comments, reels, stories, feeds, captions and more

# Reddit 

-   [bdfr (Bulk Downloader for Reddit)](https://github.com/aliparlakci/bulk-downloader-for-reddit) - Python Based Open-Source, This is a tool to download submissions or submission data from Reddit. It can be used to archive data or even crawl Reddit to gather research data. The BDFR is flexible and can be used in scripts if needed through an extensive command-line interface.
