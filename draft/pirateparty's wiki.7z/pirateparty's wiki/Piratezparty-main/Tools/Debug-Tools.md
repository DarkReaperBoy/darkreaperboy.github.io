# ADB

- ⭐ [Shizuku](https://github.com/RikkaApps/Shizuku) | [Official Site](https://shizuku.rikka.app/) |  [Playstore](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api&hl=en&gl=US) - **Allow ADB easily from your android itself**. Just connect to any Wifi network and start adb using shizuku.
  > It also allow normal apps to use system APIs directly with adb/root privileges.

  > Connect it to **Termux** and start `adb shell`. 

  > **Issue of termux normal adb way and how shizuku solve it :** Using adb in termuc from android device in which we want to connect through adb is hard!! Because changing to termux after seeing PIN from developer setting > wireless debugging, change the PIN !!. **So Shizuku allow entering PIN to pair device with adb through notification bar**

  > Use it for tasks like "Extracting Genshin Impact wish history url using `tomcat` for using it on https://paimon.moe 😁

-   [webADB](https://app.webadb.com/) - The best way to control and manage your android device using just the browser! Nothing to install or setup, just plug and play!
