# Anime Tools

-   [Anime-downloader](https://github.com/anime-dl/anime-downloader) - A simple but powerful anime downloader and streamer.
-   [Monkey-dl](https://github.com/Oshan96/monkey-dl) - Bulk download your favourite anime episodes from your favourite anime websites.
-   [Anigrab](https://github.com/ngomile/anigrab) - Anime downloader that is fast and efficient.
-   [Mass-Anime-Downloader](https://github.com/Zebraslive/Mass-Anime-Downloader) - Windows Electron App, Instantly download thousands of dubbed & subbed anime series. Download entire series in minutes.
-   [Anime-dl](https://github.com/vrienstudios/anime-dl) - ADLCore is an API and app for the download of novels, manga, and anime from a plethora of sites. It works on Windows, Linux, OSX, and Android.
-   [Anime-dl](https://github.com/gabelluardo/anime-dl) - Efficient cli app for downloading anime.
-   [Animdl](https://github.com/justfoolingaround/animdl) - A highly efficient, fast, powerful and light-weight anime downloader and streamer for your favorite anime.
-   [Animepahe-dl](https://github.com/KevCui/animepahe-dl) - Download anime videos from animepahe in terminal.
-   [Kurby](https://github.com/aberrier/kurby) - A modern CLI to download animes automatically From Twist.
-   [The_collector](https://github.com/cyberrumor/the_collector) - Tool to collect bulk mp4s from wcostream.
-   [ADL](https://github.com/RaitaroH/adl) - Anime-downloader + Trackma wrapper.
-   [Super-anime-downloader](https://github.com/ali-sajjad-rizavi/super-anime-downloader) - A program which takes an Anime name or URL and downloads the specified range of episodes.
-   [AnimeX-pack](https://github.com/Mastersam07/animeX-pack) - A lightweight Python library (and command-line utility) for downloading anime.
-   [Mayame](https://github.com/asakura42/manyame) - Anime cli xdcc download script for linux/win/mac/android.
-   [Koneko](https://github.com/irevenko/koneko) - Nyaa.si terminal BitTorrent tracker.
-   [AnimeClub](https://github.com/Moisz22/AnimeClub) - Personal web page to keep records of an anime that you have finished watching, are currently watching, or have yet to be seen.
-   [Nyaascraper](https://github.com/zaini/nyaascraper) - An application to scrape and open magnet links for fansub groups from nyaa.si where batches don't already exist.
-   [Aniloader](https://github.com/Xanahol/Aniloader) - Automated Anime-download from SubsPlease by using Web crawling, magnet links and qBittorrent!
-   [batch-downloader-nyaa](https://github.com/marcpinet/batch-downloader-nyaa.si/) - focused on making easier to batch download torrents or transfer magnets from Nyaa.si.
-   [AnIRC](https://github.com/burgersc12/AnIRC) - Automated Anime Download Via XDCC.
-   [Rss-anime-notifier](https://gitlab.com/blankX/rss-anime-notifier-rs) - RSS Anime Notifier but in Rust.
-   [fastwatch](https://github.com/ree1261/fastwatch) - stream any movie, tv show, or anime with one command.

# Movie Tools

-   [Phobos](https://github.com/billythegoat356/Phobos) - This tool written in Python3 allows you to download any movie easily thanks to Google Dorks and Google Drive!
-   [Downloader-api](https://github.com/SagarPaul007/downloader-api) - Download movies, shows, webseries, songs, software etc.
-   [Pandora](https://github.com/SagarPaul007/pandora) | [Website](https://pandora-sp.netlify.app/) - Download movies, shows, books and many things.
-   [Nefarious](https://github.com/lardbit/nefarious) - Web application for automatically downloading TV & Movies.
-   [Gophie](https://github.com/Go-phie/gophie) - An Aggregator Engine for searching and downloading movies free - NO ADs!
-   [Downlomatic](https://github.com/TimerErTim/downlomatic) - a CLI and GUI tool capable of downloading multiple or all movies/series/animes/whatever from supported websites.
-   [Hatt](https://github.com/FrenchGithubUser/Hatt) - DDL/Streaming meta search engine.

# Game Tools
-
