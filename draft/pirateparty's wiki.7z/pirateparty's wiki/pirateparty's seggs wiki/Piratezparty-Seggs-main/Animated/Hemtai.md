# Hentai

-   [Underhentai](https://www.underhentai.net/)
-   [MuchoHentai](https://MuchoHentai.com)
-   [Besthentaisites](https://besthentaisites.github.io/)
-   [999hentai](https://999hentai.com/hentai-anime)
-   [Hanime](https://Hanime.tv)
-   [Hentaigasm](https://hentaigasm.com)
-   [Hentaimama](https://hentaimama.com/)
-   [Hentaiworld](https://hentaiworld.tv/)
-   [Hentaikisa](https://hentaikisa.com)
-   [Underhentai](https://underhentai.net)
-   [Ohentai](https://ohentai.org)
-   [Hentaidude](https://hentaidude.com/)
-   [Hentaihaven](https://hentaihaven.red/)
-   [Hentaistream](https://hentaistream.moe/)
-   [Hentaicloud](https://www.hentaicloud.com/)
-   [Kisshentai](https://kisshentai.net/)
-   [Hentai2w](https://hentai2w.com/)
-   [Haho](https://haho.moe/)

# Hentai Manga

-   [Nhentai](https://nhentai.net)
-   [PorndudeList](https://theporndude.com/hentai-manga-sites)
-   [Wholesomelist](https://wholesomelist.com/)
-   [Besthentaisites](https://besthentaisites.github.io/)
-   [tsumino](https://tsumino.com)
-   [Hbrowse](https://hbrowse.com/)
-   [Doujins](https://doujins.com/)
-   [Prncomix](https://prncomix.com/)
-   [999hentai](https://999hentai.com/hentai-manga)
-   [9hentai](https://9hentai.com/)
-   [Fakku](https://fakku.net/)
-   [HentaiHere](https://hentaihere.com/)
-   [E-hentai](https://e-hentai.org/) | [Forums](https://forums.e-hentai.org/index.php)
-   [HentaiFox](https://hentaifox.com/)
-   [Hentaihand](https://hentaihand.com/en/)
-   [9hentai](https://9hentai.to/)
-   [Eahentai](https://eahentai.com/)
-   [Nyahentai](https://nyahentai.com/)
-   [HentaiShark](https://www.hentaishark.com/)
-   [Imhentai](https://imhentai.xxx/)
-   [SimplyHentai](https://simplyhentai.org/)
-   [Hentai2read](https://hentai2read.com/)
-   [HentaiRead](https://hentairead.com/)
-   [Mihentai](https://mihentai.com/)
-   [MyHentaiGallery](https://myhentaigallery.com/)
-   [HentaiComics](https://myhentaicomics.com/)

# Download

-   [Sukebei](https://sukebei.nyaa.si/)
-   [Panda](https://panda.chaika.moe/)
-   [Ryuugames](https://ryuugames.com/)
-   [Sakuracircle](https://sakuracircle.com/)
-   [moeload](https://moeload.com/)

# Apps

-   [NClientV2](https://github.com/Dar9586/NClientV2) - An unofficial NHentai android client.
-   [Hentoid](https://github.com/avluis/Hentoid) - Doujinshi Android App.
-   [EhViewer](https://gitlab.com/NekoInverter/EhViewer) - An E-Hentai Application for Android.
-   [Hentaiser](https://hentaiser.com) - The hentai, doujins and anime online reader app.
-   [Violet](https://github.com/project-violet/violet) - Flutter based Viewer App.
-   [NHViewer](https://github.com/ttdyce/NHentai-NHViewer) - NHViewer is a simple third-party nhentai client for Android.
-   [Hentai-Video-Downloader](https://github.com/Zebraslive/basic-hentai-video-downloader) - A simple hentai video downloader. Electron Windows App.
-   [Hendroid](https://github.com/Nonononoki/Hendroid) - This is a fork of Hentoid with several improvements - including removed tracking, third-party image viewer support and more!
-   [FreakMangaBrandNew](https://github.com/Abealkindy/FreakMangaBrandNew) - Browse and read hentai manga from 3 of some biggest hentai websites in one app.
-   [X-Comic-Downloader-Project](https://github.com/RealLowMaster/X-Comic-Downloader-Project) - A Software for downloading and viewing adult or hentai comics or mangas.

# Reddit Collection

-   [Wholesomehentai](https://www.reddit.com/r/wholesomehentai) | [Website](https://wholesomelist.com/) - Hentai that makes your heart orgasm.
-   [Hentai](https://www.reddit.com/r/hentai) | [List](https://reddit.com/r/hentai/w/hentai_subreddits) - Hentai Related sub.
-   [HENTAI_GIF](https://www.reddit.com/r/HENTAI_GIF) - For Hentai Animations.
-   [Hentai4Everyone](https://www.reddit.com/r/Hentai4Everyone) - Yet Another Hentai Subreddit.
-   [HentaiAnime](https://www.reddit.com/r/HentaiAnime) - About HentaiAnime.
-   [HentaiManga](https://www.reddit.com/r/HentaiManga) - NSFW subreddit dedicated to Hentai Manga adult genre.
-   [Hentaicomics](https://www.reddit.com/r/hentaicomics) - Home to your favorite hentai comics and shenanigans.
-   [HentaiSource](https://www.reddit.com/r/HentaiSource) - This subreddit is dedicated to finding and archiving sources for your fapping needs in the hentai category.
-   [Adorablehentai](https://www.reddit.com/r/adorablehentai) - Adorable hentai are those that give us warm fuzzies that make us go 'aww' and/or make us happy for the happiness of those in the story.
-   [Completedhentaimanga](https://www.reddit.com/r/Completedhentaimanga) - enjoy the compilation of every completed adult series completed.
-   [Doujinshi](https://www.reddit.com/r/doujinshi) - Lewd(er) manga, but not as lewd as hand holding.
-   [DoujinshiPanels](https://www.reddit.com/r/DoujinshiPanels) - Post panels or pages you find in Doujinshi here.
-   [Anime_Hentai](https://www.reddit.com/r/anime_hentai) - The best anime hentai collection. Find the best anime hentai videos, comics and images!
-   [AnimeMILFS](https://www.reddit.com/r/AnimeMILFS) - A community for all the anime MILF lovers out there.
-   [Ecchi](https://www.reddit.com/r/ecchi) - Ecchi - NSFW pictures of anime characters.
-   [Hentai_irl](https://www.reddit.com/r/hentai_irl) - Anime_irl's perverted sister.
-   [HentaiManga_X](https://www.reddit.com/r/hentaiManga_X) - Hentai manga of all genre.
-   [Nsfw_zhentai](https://www.reddit.com/r/nsfw_zhentai) - Hentai Community of ZHENTUBE.
-   [Sixdigits](https://www.reddit.com/r/sixdigits) - Six digit hentai codes, found in the wild. Most are intentionally shared, but it's cooler when they're posted by accident in some random sub.
-   [StierHentai](https://www.reddit.com/r/StierHentai) - Only the best of hentai!
-   [VanillaRomanceOnly](https://www.reddit.com/r/VanillaRomanceOnly) - Vanilla Romance are for those that do not cross the line in to fetish territory.

# Tools

-   [Peter-Parker](https://github.com/ChingChang9/peter-parker) - With great power comes great hentai.
-   [Comics-DL](https://github.com/The-Eye-Team/Comics-DL) - A comic archiver but supports hentai sites.
-   [E-Hentai-Downloader](https://github.com/ccloli/E-Hentai-Downloader) - Download E-Hentai archive as zip file.
-   [Yamete](https://github.com/jaymoulin/yamete) - Hentai downloader in PHP CLI.
-   [GNhentai](https://github.com/tdakkota/gnhentai) - Nhentai.net API Client.
-   [Give-Me-The-Sauce](https://github.com/on33s4m4/Give-Me-The-Sauce) - The easiest way to download that sauce.
-   [H-Manga-Downloader](https://github.com/AmbitionlessFr1end/h-manga-downloader) - A script for downloading hentai manga/doujin files and storing them in a folder.
-   [NHentaiDownloader](https://github.com/Xwilarg/NHentaiDownloader) - A chrome extension to download doujinshi from NHentai.
-   [Asuka](https://github.com/aikoofujimotoo/asuka) - A cross-platform nhentai downloader written in C#.
-   [N-Hentai-Scraper](https://github.com/SoloSynth1/n-hentai-scraper) - Simple synchronous nhentai gallery downloader.
-   [Hanime](https://github.com/lilacre/hanime) - Hanime hentai video downloader.
-   [IchBinLeoon-Hanime](https://github.com/IchBinLeoon/hanime) - Command-line tool to download videos from hanime.tv.
-   [HTV](https://github.com/rxqv/htv) - CLI tool for downloading hentai from hanime.tv.
-   [Go-Hentai-Scraper](https://github.com/gan-of-culture/go-hentai-scraper) - A hentai scraper made in go.
